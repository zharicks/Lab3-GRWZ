from socket import socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR

from threading import Thread
from queue import Queue

from Utils.Setup import setupIpConfigs, getData, setDataParameters, getConnections, beginModeling, subList
from Utils.Modeling import genTokens, getModelFromSub, getBestModel
from Misc.MakeReport import genDoc

# ---- Setup: Server ----
MAIN_IP, MAIN_PORT = setupIpConfigs()

# ---- Setup: DataFrame ----
data, dataRaw = getData()

# ---- Setup: Bifurcación Variables-Conexiones ----
RESPONSE: str = ''
REQUIRED: list[str] = []

mainSocket: socket = socket( AF_INET, SOCK_STREAM )
mainSocket.setsockopt( SOL_SOCKET, SO_REUSEADDR, 1 )
mainSocket.bind( ( MAIN_IP, MAIN_PORT ) )
mainSocket.listen( 20 )

params = Queue()
parameters = Thread( target = setDataParameters, args = [ list(data.columns), params ] )
connections = Thread( target = getConnections, args = [ mainSocket, dataRaw ] )
confirmation = Thread( target = beginModeling, args = [ ] )

parameters.start()
connections.start()

parameters.join()

RESPONSE = params.get()
REQUIRED = params.get()
VARIABLES = list(data.columns)

confirmation.start()

confirmation.join()
connections.join()

# ---- Generación de modelos ----

tokens: Queue[str] = genTokens( RESPONSE, VARIABLES, REQUIRED )
models: Queue[dict[ str:float | dict[str:float] ]] = Queue()

expModels: int = tokens.qsize()

threadList: Thread = []
for subSocket in subList:
    t = Thread( target = getModelFromSub, args = [ subSocket, tokens, models ] )
    t.start()
    threadList.append( t )

for thread in threadList:
    thread.join()

modelList: list[ dict ] = []
while not models.empty():
    modelList.append( models.get() )

bestModel = getBestModel( modelList )

print( bestModel )

genDoc( data = data, formula = bestModel['formula'] )