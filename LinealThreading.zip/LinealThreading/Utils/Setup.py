from threading import Thread, Event, Lock
from socket import gethostbyname, gethostname, timeout
import socket
from queue import Queue
from pandas import DataFrame, read_csv
from pandas.errors import ParserError, EmptyDataError
from time import sleep

from Modules.OptionMenu import OptionMenu, clear
from zlib import compress

# ---- Events ----
beginModelPhase: Event = Event()

# ---- Lock ----
lock: Lock = Lock()

# ---- Global variables ----
subList: list[ socket.socket ] = []
connList: list[ Thread ] = []

def setupIpConfigs() -> tuple[str,int]:

    ip: str = gethostbyname( gethostname() )
    port: int = 8081

    configs = OptionMenu( '¿Qué desea cambiar?', ['Dirección IP', 'Puerto', 'Volver'] )
    ipsets = OptionMenu( '¿Desea usar localhost?', ['Sí','No'] )

    while True:
        opt = OptionMenu( f'¿Iniciar proyecto con IP: {ip} y puerto: {port}?', ['Sí','No'] ).getOption()
        if opt == 0: break
        config = 0
        while config != 2:
            config = configs.getOption()
            if config == 0:
                ipset = ipsets.getOption()
                if ipset == 0: ip = 'localhost'
                else: ip = gethostbyname( gethostname() )
            elif config == 1:
                port = None
                while port is None:
                    clear()
                    try: port = int(input('¿Qué puerto desea usar?\n> '))
                    except ValueError: pass
    return ip, port

def getData() -> tuple[DataFrame,str]:
    dataRaw = None
    while not dataRaw:
        try: 
            filename = input( '¿Cual es la ruta del archivo del dataframe?\n> ' )
            data = read_csv( filename )
            dataRaw = open( filename ).read()
        except FileNotFoundError: clear(); print( 'No se encontró el archivo.' )
        except PermissionError: clear(); print( 'No se tienen permisos para abrir este archivo.' )
        except ParserError: clear(); print( 'No se puede leer este archivo.' )
        except EmptyDataError: clear(); print( 'No se encontraron datos en este archivo' )
        except UnicodeDecodeError: clear(); print( 'No se puede leer este archivo.' )
    return data, dataRaw

def setDataParameters( _variables: list[str], q: Queue ) -> tuple[ str, list[str] ]:
    marker = '\n> '
    while True:
        variables = _variables.copy()
        opt = OptionMenu( '¿Cuál es la variable respuesta (dependiente)?', variables ).getOption()
        response = variables.pop( opt )
        variables.insert( 0, 'Terminar' )
        opt = 1
        required: list[str] = []
        while opt != 0:
            opt = OptionMenu( f'Elija las variables que debe requerir el modelo\nActualmente:\n> { marker.join(required) }\n--------', variables ).getOption()
            if opt != 0: required.append( variables.pop(opt) )
        opt = OptionMenu( f'Variable dependiente: {response}\nVariables requeridas: {", ".join(required)}\n¿Continuar?', ['Sí','No'] ).getOption()
        if opt == 0:
            q.put(response)
            q.put(required)
            return

def addSub( subToAdd: socket.socket, data: str ):
    global subList
    with lock:
        subToAdd.send( b'CD01' )
        subToAdd.send( compress( data.encode('utf-8') ) )
        subToAdd.send( b'CD02' )
        subList.append( subToAdd )

def getConnections( mainSocket: socket.socket, dataRaw: str ):
    global beginModelPhase
    mainSocket.settimeout( 0.5 )
    while not beginModelPhase.is_set():
        try: 
            subSocket, subAddress = mainSocket.accept()
            Thread( target = addSub, args = [ subSocket, dataRaw ] ).start()
        except timeout:
            continue
    mainSocket.settimeout( None )

def beginModeling():
    global beginModelPhase
    global subList
    while not beginModelPhase.is_set():
        opt = OptionMenu( f'Actuamente hay {len(subList)} conexiones.\n¿Desea continuar?', ['Sí','...'] ).getOption()
        with lock:
            if opt == 0: beginModelPhase.set()
