from itertools import combinations
from queue import Queue
from socket import socket
from threading import Lock
from json import loads

getTokenLock: Lock = Lock()

def genTokens( response: str, variables: list[str], required: list[str]) -> Queue[ str ]:
    tokens: Queue[str] = Queue()
    tokenList: list[str] = []
    for n in range( len( variables ), 0, -1 ):
        for comb in combinations( set(variables) - set(required) - set([response]), n ):
            comb += tuple(required)
            tokenList.append( response + ' ~ ' + ' + '.join( comb ))
    for token in tokenList: tokens.put( token )
    return tokens

def getModelFromSub( subSocket: socket, tokens: Queue[str], models: Queue[dict[ str:float | dict[str:float] ]] ):
    while not tokens.empty():
        with getTokenLock: token = tokens.get()
        subSocket.send( token.encode('utf-8') )
        model = subSocket.recv( 2048 )
        if model: 
            model = model.decode('utf-8')
            models.put(loads( model ))
        else: 
            with getTokenLock: 
                tokens.put( token )
                return
        
def getBestModel( models: dict ):

    rosqr = [ model['rosqr'] for model in models ]
    models = [ model for model in models if model['rosqr'] == max( rosqr ) ]
    print(f'Modelos con el mejor ro cuadrado ({max(rosqr)}): {len(models)}...')
    if len( models ) == 1: return models[0]

    aic = [ model['aic'] for model in models ]
    models = [ model for model in models if model['aic'] == min(aic)  ]
    print(f'Modelos con el mejor AIC ({min(aic)}): {len(models)}...')
    if len( models ) == 1: return models[0]

    bic = [ model['bic'] for model in models ]
    models = [ model for model in models if model['bic'] == min(bic)  ]
    print(f'Modelos con el mejor BIC ({min(bic)}): {len(models)}...')
    if len( models ) == 1: return models[0]

    varlen = [ model['varlen'] for model in models ]
    models = [ model for model in models if model['varlen'] == min(varlen)  ]
    print(f'Modelos con menos variables ({min(varlen)}): {len(models)}...')
    
    return models[0]




