import socket
from zlib import decompress
from statsmodels.formula.api import ols
from json import dumps
from pandas import *
from statsmodels.regression.linear_model import RegressionResultsWrapper

s = socket.socket()
s.connect(("172.31.3.40",8081))

print('Setup...')
dataGet = False
dataRaw = b''
while True:
    received = s.recv(2048)
    if received:
        if received == b'CD01': 
            print( 'Receiving data...' )
            dataGet = True
        elif received[-4:] == b'CD02': 
            dataRaw += received[:-4]
            print( 'Processing data...' )
            dataRaw = decompress(dataRaw).decode()
            head = ''
            for c in dataRaw:
                if c != '\n': head += c
                else: break
            print( f'Data loaded:\n> { head }...' )
            break
        elif dataGet:
            dataRaw += received 

print("Waiting for modeling process to start...")

rows = dataRaw.split('\n')
head = rows[0].split(',')
if rows[-1] == '':
    rows.pop(-1)
data = [ [ float(value) for value in row.split(',') ] for row in rows[1:] ]
data: DataFrame = DataFrame( data[1:], columns = head )

print( data.head(6) )

def linearRegression( formula: str ):
    model: RegressionResultsWrapper = ols( formula = formula, data = data ).fit()
    summary: dict = {
        'formula': formula,
        'varlen': len(formula.split('+')),
        'rosqr': model.rsquared_adj,  
        'aic': model.aic,
        'bic': model.bic,
        'coeffs': dict(model.params),
        'pvalues': dict(model.pvalues)
    }
    return dumps( summary )

while True:
    token = s.recv( 2048 )
    if token:
        formula = token.decode( 'utf-8' )
        print( 'Model: ' + formula )
        result = linearRegression( formula )
    s.send( result.encode('utf-8') )
    print( result )

print('bye')
s.close()