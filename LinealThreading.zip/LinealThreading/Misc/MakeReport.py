from statsmodels.formula.api import ols
import base64
from plotnine import ggplot, aes, geom_point, geom_smooth, labs
from pandas import DataFrame


def geom_regression( data, response, variables):
    plot = ggplot(data, aes(x=variables[0], y=response))
    plot += geom_point()
    plot += geom_smooth(method='lm', se=False, color='red')
    plot += labs(title='Recta de Regresión')
    return plot

def genDoc( data: DataFrame, formula: str ):

    # Incluir estilo CSS en el HTML
    estilo_css = """
    <style>
    body {
        font-family: 'Arial', sans-serif;
        line-height: 1.6;
        margin: 20px;
    }

    h1, h2, h3 {
        color: #333;
    }

    table {
        border-collapse: collapse;
        width: 80%;
        margin: 20px 0;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    p {
        margin-bottom: 15px;
    }

    img {
        max-width: 100%;
        height: auto;
        margin: 20px 0;
    }

    </style>
    """

    # Crear archivo HTML y escribir contenido
    with open('informe.html', 'w') as file:
        # Escribir estilo CSS en el HTML
        file.write(estilo_css)

        # Agregar título
        file.write('<h1>Informe de Regresión Lineal</h1>')

        # Resumen de datos
        file.write('<h2>Resumen de Datos</h2>')
        file.write(data.describe().to_html())

        # Calcular correlación
        correlacion = data.corr( method='spearman' )
        file.write('<h2>Matriz de Correlación</h2>')
        file.write(correlacion.to_html())

        model = ols( formula = formula, data = data ).fit()

        # Obtener las variables utilizadas en el mejor modelo ajustado
        variables = [var for var in model.model.exog_names if var != 'Intercept']

        # Imprimir información del mejor modelo
        file.write('<h2>Mejor Modelo</h2>')
        file.write(model.summary().as_html())

        # Crear gráfico de la recta de regresión
        file.write('<h2>Recta de Regresión</h2>')
        plot_recta_regresion = geom_regression(data, 'y', variables)
        plot_recta_regresion.save('recta_regresion_ggplot.png')

        # Convertir la imagen a base64
        with open('recta_regresion_ggplot.png', 'rb') as image_file:
            encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

        # Incluir la imagen en el HTML
        file.write(f'<img src="data:image/png;base64,{encoded_image}" alt="Recta de Regresión">')

    print("Informe generado exitosamente.")
