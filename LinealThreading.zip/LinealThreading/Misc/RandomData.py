from numpy import random
import pandas as pd

obs = 10000

random.seed( obs )

def err( mean: float, sd: float ):
  return [ round( value, 2 ) for value in random.normal( loc = mean, scale = sd, size = obs ) ]

# Variables principales: x1( 15, 1 ), x2( 5, 2 )
# Variable desc: y = 3.14 * x1 - 2 * x2 + err( 0, 0.01 )
# Variables basura: basura, trash, mull, immondizia
# Variables covariadas: cov1 ( 0.7 * x1 + err( 0, 1 ) ), cov2 ( 4 + 2 * x2 + err( 0, 2 ) ), cov3 ( x1 + x2 + basura + err( 0, 0.5 ) ), cov4 ( basura + trash + mull + 15*immondizia )

data = {
    'y': None,
    'x1': err( 15, 1 ),
    'x2': err( 5, 2 ),
    'basura': err( 145, 50 ),
    'trash': err( 169, 13 ),
    'mull': err( -1000, 50 ),
    'immondizia': err( - 675, 675 )
}

def gen( delta: float, betas: dict[ str: float ], mean: float, sd: float ):
  column = []
  for i, e in enumerate( err( mean, sd ) ):
    row = e + delta
    for j, var in enumerate( betas ):
      row += data[ var ][i] * betas[ var ]
    column.append( round(row, 2) )
  return column

data['y'] = gen( 2.71, { 'x1': 3.14, 'x2': -2 }, 0, 0.01 )

covs = {
    'cov1': gen( 0, { 'x1': 0.7 }, 0, 1 ),
    'cov2': gen( 4, { 'x2': 2 }, 0, 2 ),
    'cov3': gen( 15, { 'x1': 2, 'x2': 3, 'basura': 5 }, 0, 0.5 ),
    'cov4': gen( 0, { 'basura': 1, 'trash': 1, 'mull': 1, 'immondizia':12 }, 15, 50 )
}

data = data | covs

data = pd.DataFrame(data)

data.to_csv( 'data.csv', index = False )