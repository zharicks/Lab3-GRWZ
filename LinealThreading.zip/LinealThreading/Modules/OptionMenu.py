import keyboard
import os
import time

def clear() -> None:
    os.system( 'cls' if os.name == 'nt' else 'clear' )

class OptionMenu:
    def __init__( self, msg: str, items: list[str], cursor: str = '>' ) -> None:
        self.msg = msg
        self.items = items
        self.selected = 0
        self.cursor = cursor
        self.void = ''.join([ ' ' for i in range(len(self.cursor)) ])
        self.len = len( self.items )

    def display( self ) -> None:
        clear()
        print( self.msg )
        for index, item in enumerate( self.items ):
            if self.selected == index:
                print( f'{self.cursor} {item}' )
            else:
                print( f'{self.void} {item}' )

    def getOption( self ) -> int:
        self.display()
        while keyboard.is_pressed('enter'):
            pass
        while True:
            if keyboard.is_pressed('up'):
                self.selected -= 1
                self.selected = ( self.selected + self.len ) % self.len
                self.display()
                time.sleep(0.3)

            elif keyboard.is_pressed('down'):
                self.selected += 1
                self.selected %= self.len
                self.display()
                time.sleep(0.3)

            elif keyboard.is_pressed('enter'):
                input(); clear()
                return self.selected
